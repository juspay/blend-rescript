type accordionType =
  | @as("border") BORDER
  | @as("noBorder") NO_BORDER

type accordionChevronPosition =
  | @as("left") LEFT
  | @as("right") RIGHT

type slotRenderProps = {
  isExpanded: bool,
  toggle: unit => unit,
  value: string,
  isDisabled: bool,
}

type slotType = [
  | #Element(React.element)
  | #Render(slotRenderProps => React.element)
]

type widthValue = [
  | #String(string)
  | #Int(int)
]

type accordionItemProps = {
  value: string,
  title: string,
  subtext?: string,
  leftSlot?: React.element,
  rightSlot?: React.element,
  subtextSlot?: React.element,
  triggerSlot?: slotType,
  triggerSlotWidth?: widthValue,
  children: React.element,
  isDisabled?: bool,
  chevronPosition?: accordionChevronPosition,
}

@module("@juspay/blend-design-system") @react.component
external make: (
  ~children: React.element,
  ~accordionType: accordionType=?,
  ~defaultValue: string=?,
  ~value: string=?,
  ~isMultiple: bool=?,
  ~onValueChange: array<string> => unit=?,
  ~ref: React.ref<Js.Nullable.t<Dom.element>>=?,
) => React.element = "Accordion"