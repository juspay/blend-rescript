// Button Types
type buttonType =
  | @as("primary") PRIMARY
  | @as("secondary") SECONDARY
  | @as("danger") DANGER
  | @as("success") SUCCESS

type buttonSize =
  | @as("sm") SMALL
  | @as("md") MEDIUM
  | @as("lg") LARGE

type buttonSubType =
  | @as("default") DEFAULT
  | @as("iconOnly") ICON_ONLY
  | @as("inline") INLINE

type buttonState =
  | @as("default") DEFAULT
  | @as("hover") HOVER
  | @as("active") ACTIVE
  | @as("disabled") DISABLED

type buttonGroupPosition = [#center | #left | #right]

type width = [#String(string) | #Number(float)]

@module("@juspay/blend-design-system") @react.component
external make: (
  ~buttonType: buttonType=?,
  ~size: buttonSize=?,
  ~subType: buttonSubType=?,
  ~text: string=?,
  ~leadingIcon: React.element=?,
  ~trailingIcon: React.element=?,
  ~disabled: bool=?,
  ~onClick: ReactEvent.Mouse.t => unit=?,
  ~loading: bool=?,
  ~showSkeleton: bool=?,
  ~skeletonVariant: string=?,
  ~buttonGroupPosition: buttonGroupPosition=?,
  ~fullWidth: bool=?,
  ~width: width=?,
  ~justifyContent: string=?,
  ~state: buttonState=?,
  ~className: string=?,
  ~style: 'style=?,
  ~children: React.element=?,
  ~key: string=?,
) => React.element = "Button"